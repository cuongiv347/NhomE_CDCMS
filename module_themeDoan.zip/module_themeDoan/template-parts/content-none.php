<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Do An Nhom E
 */

?>

<section class="no-results not-found">
	<?php get_template_part('module/module9/module9','none'); ?>    
</section><!-- .no-results -->
