<!--Swiper-->
<?php echo do_shortcode( " [wonderplugin_slider id=2]" ) ?>